# MDM व्यय कैलकुलेटर — Android ऐप

प्रस्तुतकर्ता: प्रबल (स०अ०), कादरचौक, बदायूँ · Instagram @darshanikbharat

## ऐप में क्या है
- पूरा कैलकुलेटर व रिपोर्ट **बिना इंटरनेट** के चलता है (HTML ऐप के अंदर रखा है)
- छात्र संख्या व बदले गए भाव **याद रहते हैं** — ऐप दोबारा खोलने पर वही मिलते हैं
- **"परिणाम साझा करें"** बटन — WhatsApp आदि पर सारांश भेजें
- Instagram बटन सीधे Instagram ऐप में खुलता है
- स्प्लैश स्क्रीन, अपना आइकन, डार्क मोड, बैक बटन सही काम करता है

## APK कैसे बनाएँ

### तरीका 1 — GitHub से (कंप्यूटर की ज़रूरत नहीं, मोबाइल से भी हो जाता है)
1. github.com पर नया repository बनाएँ (जैसे `mdm-app`)
2. इस ZIP की सारी फ़ाइलें/फ़ोल्डर उसमें upload करें (`.github` फ़ोल्डर ज़रूर रहे)
3. **Actions** टैब खोलें → "Build APK" अपने-आप चलेगा (~5 मिनट)
4. पूरा होने पर नीचे **MDM-Calculator-APK** डाउनलोड करें → ZIP खोलें → APK फ़ोन में install करें

### तरीका 2 — Android Studio से
1. Android Studio में **File → Open** करके यह फ़ोल्डर खोलें
2. Gradle sync होने दें → **Build → Build APK(s)**

## हर माह भाव बदलना
`app/src/main/assets/index.html` में ऊपर `price-data` वाला हिस्सा बदलें,
`app/build.gradle` में `versionCode` 1 बढ़ाएँ, और नया APK बनाएँ।
(उपयोगकर्ता ऐप के अंदर भी भाव बदल सकते हैं।)

## Play Store पर डालने से पहले
अभी APK debug key से साइन है (सीधे install के लिए ठीक)। Play Store के लिए
Android Studio में **Build → Generate Signed Bundle** से अपनी key बनाएँ और उसे सँभालकर रखें।
